"""
CampusSafe - Configuration Module
Loads environment variables and sets up application configuration.
"""

import os
from dotenv import load_dotenv

# Load variables from .env file
load_dotenv()

class Config:
    # Flask Session & Security Key
    SECRET_KEY = os.getenv("SECRET_KEY", "campus-safe-dev-fallback-key-change-in-production")
    
    # MongoDB Atlas Settings
    MONGO_URI = os.getenv("MONGO_URI", "")
    MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "campus_safety_db")
    
    # Connection timeouts (milliseconds)
    MONGO_TIMEOUT_MS = 5000
    
    # Flask session cookies
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    PERMANENT_SESSION_LIFETIME = 86400  # 24 hours in seconds

    @staticmethod
    def is_mongo_configured() -> bool:
        """Returns True if MONGO_URI is set and is not the default placeholder."""
        uri = os.getenv("MONGO_URI", "").strip()
        if not uri:
            return False
        if "YOUR_REAL_MONGODB_ATLAS_CONNECTION_STRING" in uri or "YOUR_ATLAS_URI" in uri:
            return False
        return True
